import { SearchMode } from "agent-twitter-client";
import { scraper } from "../config";
import db, { schema } from "../drizzle";
import { eq } from "drizzle-orm";
import { buyToken, createWallet } from "../util";

let checkNewTweetsRunning = false;

async function checkNewTweets() {
  try {
    if (checkNewTweetsRunning) return;
    checkNewTweetsRunning = true;

    const tweets = await scraper.fetchSearchTweets(
      `@askDJTrump`,
      20,
      SearchMode.Latest
    );

    for (const tweet of tweets.tweets) {
      if (tweet.userId === "1922719994422624259") {
        continue;
      }

      const [existingTweet] = await db
        .select()
        .from(schema.processedTweet)
        .where(eq(schema.processedTweet.id, tweet.id!));

      if (existingTweet) {
        continue;
      }

      await db.insert(schema.processedTweet).values({
        id: tweet.id!,
        userId: tweet.userId!,
      });

      console.log("New tweet found:", tweet.text);

      const [user] = await db
        .select()
        .from(schema.user)
        .where(eq(schema.user.id, tweet.userId!));

      const text = tweet.text?.replace(/@\w+/g, "").trim();

      const command = text?.split(" ")[0]?.toLowerCase();

      if (!user) {
        const wallet = await createWallet();
        const res = await db
          .insert(schema.user)
          .values({
            id: tweet.userId!,
            privateKey: wallet.privateKey,
            publicKey: wallet.publicKey,
          })
          .returning();

        const reply = `Welcome to XZap! Your wallet is: ${wallet.publicKey}. Please fund the wallet to make trades. DM 'export' to export private key  https://twitter.com/messages/compose?recipient_id=1922719994422624259`;

        await scraper.sendTweet(reply, tweet.id!);
      } else if (command === "buy") {
        if (!tweet.inReplyToStatusId) {
          continue;
        }

        const parentTweet = await scraper.getTweet(tweet.inReplyToStatusId);

        const address = parentTweet?.urls?.[0]?.split("/").pop();

        const [amount, currency] = text!.split(" ").slice(1);

        try {
          const buyRes = await buyToken({
            input: currency as "USDC" | "SOL" | "USDT",
            output: address!,
            amount: Number(amount),
            privateKey: user.privateKey,
          });

          const messageText = `Bought ${buyRes.output} of ${address} for ${buyRes.input} ${currency}. https://solscan.io/tx/${buyRes.signature}`;

          await scraper.sendTweet(messageText, tweet.id!);
        } catch (error) {
          const messageText = `Error buying token: ${error}`;
          await scraper.sendTweet(messageText, tweet.id!);
        }
      }
    }
  } catch (error) {
    console.error("Error checking for new tweets:", error);
  } finally {
    checkNewTweetsRunning = false;
    scheduleNextCheck();
  }
}

function scheduleNextCheck() {
  const interval = Math.floor(Math.random() * 2000) + 1000;
  console.log(`Next check in ${interval}ms`);
  setTimeout(checkNewTweets, interval);
}

scheduleNextCheck();
