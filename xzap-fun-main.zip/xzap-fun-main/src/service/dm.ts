import { eq, is } from "drizzle-orm";
import { redis, scraper } from "../config";
let checkNewDMRunning = false;
import db, { schema } from "../drizzle";
import { buyToken, createWallet, getBalance } from "../util";
import { isAddress } from "@solana/kit";

async function checkNewDM() {
  console.log("Checking for new DMs...");
  try {
    if (checkNewDMRunning) {
      return;
    }
    checkNewDMRunning = true;

    //@ts-ignore
    const res = await scraper.getDirectMessageConversations();

    const promises = res.conversations
      .map((conversation) => {
        return conversation.messages.map(async (message) => {
          if (message.senderId === "1922719994422624259") {
            return;
          }

          const [existingDm] = await db
            .select()
            .from(schema.processedDm)
            .where(eq(schema.processedDm.id, message.id));
          if (existingDm) {
            return;
          }

          await (async () => {
            console.log(`New DM from ${message.senderId}: ${message.text}`);

            const redisUser = await redis.get(`user:${message.senderId}`);

            const [user] = redisUser
              ? [
                  JSON.parse(redisUser) as {
                    id: string;
                    privateKey: string;
                    publicKey: string;
                    exported: boolean;
                    defaultBuyAmount: string;
                    defaultSellPercentage: string;
                    defaultCurrency: "USDC" | "SOL" | "USDT";
                    createdAt: Date;
                    updatedAt: Date;
                  },
                ]
              : await db
                  .select()
                  .from(schema.user)
                  .where(eq(schema.user.id, message.senderId));

            if (!user) {
              const wallet = await createWallet();
              const res = await db
                .insert(schema.user)
                .values({
                  id: message.senderId,
                  privateKey: wallet.privateKey,
                  publicKey: wallet.publicKey,
                })
                .returning();

              await redis.set(`user:${message.senderId}`, JSON.stringify(res));

              const welcomeMessage = `${wallet.publicKey}`;

              await scraper.sendDirectMessage(
                conversation.conversationId,
                welcomeMessage
              );
            } else {
              const command = message.text.split(" ")[0]?.toLowerCase();
              if (command === "export") {
                await scraper.sendDirectMessage(
                  conversation.conversationId,
                  `Your private key is: ${user.privateKey}`
                );
                const [_user] = await db
                  .update(schema.user)
                  .set({ exported: true })
                  .where(eq(schema.user.id, message.senderId))
                  .returning();
                await redis.set(
                  `user:${message.senderId}`,
                  JSON.stringify(_user)
                );
              } else if (command === "/positions") {
                const positions = await getBalance(user.publicKey);
                await scraper.sendDirectMessage(
                  conversation.conversationId,
                  `Your positions are: ${JSON.stringify(positions)}`
                );
              } else if (command === "/reset") {
                const wallet = await createWallet();
                await db.insert(schema.resettedWallet).values({
                  privatekey: wallet.privateKey,
                });
                const [user] = await db
                  .update(schema.user)
                  .set({
                    privateKey: wallet.privateKey,
                    publicKey: wallet.publicKey,
                    exported: false,
                  })
                  .returning();

                await redis.set(
                  `user:${message.senderId}`,
                  JSON.stringify(user)
                );

                await scraper.sendDirectMessage(
                  conversation.conversationId,
                  `Your wallet has been reset. New public key: ${wallet.publicKey}`
                );
              } else if (command === "/buy") {
                let [address, amount, currency] = message.text
                  .split(" ")
                  .slice(1);

                if (!address) {
                  await scraper.sendDirectMessage(
                    conversation.conversationId,
                    "Please provide a token address."
                  );
                  return;
                }

                if (!isAddress(address)) {
                  await scraper.sendDirectMessage(
                    conversation.conversationId,
                    "Please provide a valid token address."
                  );
                  return;
                }

                currency = currency
                  ? currency.toUpperCase()
                  : user.defaultCurrency;

                if (!["USDC", "SOL", "USDT"].includes(currency)) {
                  await scraper.sendDirectMessage(
                    conversation.conversationId,
                    "Please provide a valid currency (USDC, SOL, USDT)."
                  );
                  return;
                }

                amount =
                  amount && !isNaN(Number(amount))
                    ? amount
                    : user.defaultBuyAmount;

                const quantity = Number(amount);

                if (!quantity || quantity <= 0) {
                  await scraper.sendDirectMessage(
                    conversation.conversationId,
                    "Please provide a valid amount greater than 0."
                  );
                  return;
                }

                try {
                  const buyRes = await buyToken({
                    input: currency as "USDC" | "SOL" | "USDT",
                    output: address,
                    amount: quantity,
                    privateKey: user.privateKey,
                  });

                  const messageText = `Bought ${buyRes.output} of ${address} for ${buyRes.input} ${currency}.
                Transaction signature: https://solscan.io/tx/${buyRes.signature}`;
                  await scraper.sendDirectMessage(
                    conversation.conversationId,
                    messageText
                  );
                } catch (error) {
                  const messageText = `Error buying token: ${error}`;
                  await scraper.sendDirectMessage(
                    conversation.conversationId,
                    messageText
                  );
                }
              }
            }
          })();

          await db.insert(schema.processedDm).values({
            id: message.id,
            userId: message.senderId,
          });

          /*
            DM allowed format
            1. /export
            2. /positions
            3. /sell tokename/address USDC/SOL/USDT (address is optional)
            4. /buy tokename/address amount USDC/SOL/USDT (address is optional)
            5. /setdefaultbuy USDC/SOL/USDT amount


          */
        });
      })
      .flat();
    await Promise.all(promises);
  } catch (error) {
    console.error("Error checking for new DMs:", error);
  } finally {
    checkNewDMRunning = false;
    scheduleNextCheck();
  }
}

function scheduleNextCheck() {
  const interval = Math.floor(Math.random() * 2000) + 1000;
  console.log(`Next check in ${interval}ms`);
  setTimeout(checkNewDM, interval);
}

scheduleNextCheck();
