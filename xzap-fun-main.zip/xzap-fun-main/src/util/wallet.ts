import {
  createKeyPairFromPrivateKeyBytes,
  getAddressFromPublicKey,
} from "@solana/kit";
import { Keypair, VersionedTransaction } from "@solana/web3.js";
import { base58 } from "@scure/base";
import env from "../env";

const TOKENS = {
  USDC: {
    address: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    decimal: 6,
    name: "USDC",
  },
  USDT: {
    address: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
    decimal: 6,
    name: "USDT",
  },
  SOL: {
    address: "So11111111111111111111111111111111111111112",
    decimal: 9,
    name: "SOL",
  },
};

export async function createWallet() {
  const privateKeyBytes = crypto.getRandomValues(new Uint8Array(32));
  const keypair = await createKeyPairFromPrivateKeyBytes(privateKeyBytes);
  const publicKey = await getAddressFromPublicKey(keypair.publicKey);
  const publicKeyBytes = base58.decode(publicKey);
  const secretBytes = new Uint8Array([...privateKeyBytes, ...publicKeyBytes]);
  const privateKey = base58.encode(secretBytes);

  return {
    publicKey,
    privateKey,
  };
}

export async function getBalance(address: string) {
  const options = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: `{"jsonrpc":"2.0","id":"1","method":"getAssetsByOwner","params":{"ownerAddress": "${address}","options":{"showZeroBalance":false,"showCollectionMetadata":false,"showUnverifiedCollections":false,"showGrandTotal":false,"showFungible":true,"showNativeBalance":true,"showInscription":false}}}`,
  };

  const res = await fetch(env.RPC_URL, options);
  if (!res.ok) {
    throw new Error(`Error fetching balance: ${res.statusText}`);
  }
  type NativeBalance = {
    lamports: number;
    price_per_sol: number;
    total_price: number;
  };

  type TokenInfo = {
    balance: number;
    decimals: number;
    price_info: {
      price_per_token: number;
      total_price: number;
    };
  };

  type Item = {
    id: string;
    interface: string;
    content: {
      metadata: {
        name: string;
        description: string;
        symbol: string;
      };
    };
    token_info: TokenInfo;
  };

  type GetAssetsByOwnerResult = {
    nativeBalance: NativeBalance;
    items: Item[];
  };

  type GetAssetsByOwnerResponse = {
    result: GetAssetsByOwnerResult;
  };

  const data = (await res.json()) as GetAssetsByOwnerResponse;

  const filtered = data.result.items
    .filter((item) => item.interface === "FungibleToken")
    .map((item) => ({
      address: item.id,
      name: item.content.metadata.name,
      description: item.content.metadata.description,
      symbol: item.content.metadata.symbol,
      balance: item.token_info.balance,
      decimals: item.token_info.decimals,
      pricePerToken: item.token_info.price_info.price_per_token,
      totalPrice: item.token_info.price_info.total_price,
    }));

  return {
    sol: data.result.nativeBalance,
    tokens: filtered,
  };
}

export async function swap({
  input,
  output,
  amount,
  privateKey,
}: {
  input: {
    name: string;
    address: string;
    decimal: number;
  };
  output: {
    name: string;
    address: string;
    decimal: number;
  };
  amount: number;
  privateKey: string;
}) {
  const privateKeyBytes = base58.decode(privateKey);

  const keypair = Keypair.fromSecretKey(privateKeyBytes);

  const publicKey = keypair.publicKey.toBase58();

  const order = (await (
    await fetch(
      `https://lite-api.jup.ag/ultra/v1/order?inputMint=${input.address}&outputMint=${output.address}&amount=${
        amount * 10 ** input.decimal
      }&taker=${publicKey}`
    )
  ).json()) as {
    requestId: string;
    transaction: string;
  };

  if (!order.transaction) {
    throw new Error(
      `Swap order creation failed: Ensure you have sufficient ${input.name} balance and try adjusting the amount.`
    );
  }

  const transaction = VersionedTransaction.deserialize(
    Buffer.from(order.transaction, "base64")
  );
  transaction.sign([keypair]);
  const signedTransaction = Buffer.from(transaction.serialize()).toString(
    "base64"
  );

  const execution = (await (
    await fetch("https://lite-api.jup.ag/ultra/v1/execute", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        signedTransaction,
        requestId: order.requestId,
      }),
    })
  ).json()) as {
    status: string;
    error?: string;
    signature: string;
    totalInputAmount: string;
    totalOutputAmount: string;
  };

  if (execution.status !== "Success") {
    throw new Error(
      `Swap execution failed: ${execution.status} - ${execution.error}. Please try again.`
    );
  }

  return {
    signature: execution.signature,
    input: Number(execution.totalInputAmount) / 10 ** input.decimal,
    output: Number(execution.totalOutputAmount) / 10 ** output.decimal,
  };
}

async function getAsset(address: string) {
  const options = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: `{"jsonrpc":"2.0","id":"1","method":"getAsset","params":{"id":"${address}","options":{"showInscription":false}}}`,
  };

  const res = await fetch(env.RPC_URL, options);
  if (!res.ok) {
    throw new Error(`Error fetching asset: ${res.statusText}`);
  }

  return res.json() as Promise<{
    result: {
      id: string;
      interface: string;
      content: {
        metadata: {
          name: string;
          description: string;
          symbol: string;
        };
      };
      token_info: {
        balance: number;
        decimals: number;
        price_info: {
          price_per_token: number;
          total_price: number;
        };
      };
    };
  }>;
}

export async function buyToken({
  input,
  output,
  amount,
  privateKey,
}: {
  input: "USDC" | "SOL" | "USDT";
  output: string;
  amount: number;
  privateKey: string;
}) {
  const inputToken = TOKENS[input];
  const res = await getAsset(output);

  if (res.result.interface !== "FungibleToken") {
    throw new Error(`Invalid input token: ${input}`);
  }

  const outputToken = {
    name: res.result.content.metadata.name,
    address: res.result.id,
    decimal: res.result.token_info.decimals,
  };

  const swapRes = await swap({
    input: inputToken,
    output: outputToken,
    amount,
    privateKey,
  });

  return {
    inputToken,
    outputToken,
    ...swapRes,
  };
}

export async function sellToken({
  input,
  output,
  percentage,
  privateKey,
}: {
  output: "USDC" | "SOL" | "USDT";
  input: string;
  percentage: number;
  privateKey: string;
}) {}
