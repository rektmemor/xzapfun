import { Scraper } from "agent-twitter-client";
import env from "../env";

const scraper = new Scraper();

const cookies = JSON.parse(env.TWITTER_COOKIES);

const parsedCookies: string[] = [];

cookies.map((c: any) => {
  const cookie = `${c.name}=${c.value}; Domain=${c.domain}; Path=${c.path}; Secure; SameSite=${c.sameSite}; Expires=${new Date(c.expirationDate * 1000).toUTCString()}`;
  parsedCookies.push(cookie);
});

await scraper.setCookies(parsedCookies);

if (await scraper.isLoggedIn()) {
  console.log("Successfully logged in to Twitter");
} else {
  throw new Error("Failed to log in to Twitter. Please check your cookies.");
}

export default scraper;
