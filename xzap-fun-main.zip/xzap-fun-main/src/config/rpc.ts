import { createSolanaRpc } from "@solana/kit";
import env from "../env";

export default createSolanaRpc(env.RPC_URL);
