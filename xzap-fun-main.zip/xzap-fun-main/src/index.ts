import "./service/dm";
import "./service/tweet";

// import { createWallet } from "./util";

// await createWallet().then((wallet) => {
//   console.log("Public Key:", wallet.publicKey);
//   console.log("Private Key:", wallet.privateKey);
// });

//positions
//export
//sell tokenname
//setdefaultbuy
//setdefaultsell
//setdefaultcurrency usdc, usdc, sol
