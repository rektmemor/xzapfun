import {
  pgTable,
  text,
  timestamp,
  varchar,
  boolean,
  numeric,
  pgEnum,
} from "drizzle-orm/pg-core";

export const defaultCurrency = pgEnum("default_currency", [
  "USDC",
  "SOL",
  "USDT",
]);

export const user = pgTable("user", {
  id: varchar("id", { length: 255 }).primaryKey(),
  privateKey: text("private_key").notNull(),
  publicKey: varchar("public_key", { length: 44 }).notNull(),
  exported: boolean("exported").notNull().default(false),
  defaultBuyAmount: numeric("default_buy_amount").notNull().default("0"),
  defaultSellPercentage: numeric("default_sell_percentage")
    .notNull()
    .default("0"),
  defaultCurrency: defaultCurrency("default_currency").notNull().default("SOL"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .$onUpdate(() => new Date()),
});

export const resettedWallet = pgTable("resetted_wallet", {
  privatekey: text("private_key").notNull().primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const processedTweet = pgTable("processed_tweet", {
  id: varchar("id", { length: 255 }).primaryKey(),
  userId: varchar("user_id", { length: 255 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const processedDm = pgTable("processed_dm", {
  id: varchar("id", { length: 255 }).primaryKey(),
  userId: varchar("user_id", { length: 255 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});
