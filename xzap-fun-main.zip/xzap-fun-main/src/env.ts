const { TWITTER_COOKIES, DATABASE_URL, RPC_URL, REDIS_URL } = process.env;

if (!TWITTER_COOKIES) {
  throw new Error("TWITTER_COOKIES environment variable is not set");
}

if (!DATABASE_URL || !REDIS_URL) {
  throw new Error("DATABASE_URL or REDIS_URL environment variable is not set");
}

if (!RPC_URL) {
  throw new Error("RPC_URL environment variable is not set");
}

export default {
  TWITTER_COOKIES,
  DATABASE_URL,
  RPC_URL,
  REDIS_URL,
};
